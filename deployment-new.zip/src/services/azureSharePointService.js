const { Client } = require('@microsoft/microsoft-graph-client');
const { DefaultAzureCredential } = require('@azure/identity');

class AzureSharePointService {
  constructor() {
    // Use managed identity in Azure or service principal
    this.credential = new DefaultAzureCredential();
    this.graphClient = Client.initWithMiddleware({
      authProvider: {
        getAccessToken: async () => {
          const token = await this.credential.getToken(['https://graph.microsoft.com/.default']);
          return token.token;
        }
      }
    });
    
    this.siteId = process.env.SHAREPOINT_SITE_ID;
    this.driveId = process.env.SHAREPOINT_DRIVE_ID; 
    this.csvFolderPath = process.env.CSV_FOLDER_PATH || '/Shared Documents/Helpdesk';
  }

  async getLatestTicketCSV() {
    try {
      console.log('🔍 Searching for latest ticket CSV...');
      
      // Get files from SharePoint folder
      const files = await this.graphClient
        .api(`/sites/${this.siteId}/drives/${this.driveId}/root:${this.csvFolderPath}:/children`)
        .get();

      // Find CSV files matching pattern
      const csvFiles = files.value.filter(file => 
        file.name.match(/Ticket_Data_\d{4}-\d{2}-\d{2}\.csv$/i)
      );

      if (csvFiles.length === 0) {
        throw new Error('No ticket CSV files found in SharePoint');
      }

      // Sort by modification date (newest first)
      csvFiles.sort((a, b) => new Date(b.lastModifiedDateTime) - new Date(a.lastModifiedDateTime));
      
      const latestFile = csvFiles[0];
      console.log(`📄 Found latest CSV: ${latestFile.name}`);

      // Download file content
      const fileContent = await this.graphClient
        .api(`/sites/${this.siteId}/drives/${this.driveId}/items/${latestFile.id}/content`)
        .get();

      return {
        filename: latestFile.name,
        content: fileContent,
        lastModified: latestFile.lastModifiedDateTime
      };

    } catch (error) {
      console.error('❌ SharePoint access failed:', error);
      throw new Error(`Failed to access SharePoint: ${error.message}`);
    }
  }

  async getTodaysCSV() {
    try {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
      const expectedFileName = `Ticket_Data_${today}.csv`;
      
      console.log(`🔍 Looking for today's file: ${expectedFileName}`);

      // Try to get specific file
      const fileResponse = await this.graphClient
        .api(`/sites/${this.siteId}/drives/${this.driveId}/root:${this.csvFolderPath}/${expectedFileName}`)
        .get();

      const fileContent = await this.graphClient
        .api(`/sites/${this.siteId}/drives/${this.driveId}/items/${fileResponse.id}/content`)
        .get();

      return {
        filename: expectedFileName,
        content: fileContent,
        lastModified: fileResponse.lastModifiedDateTime
      };

    } catch (error) {
      console.warn(`⚠️ Today's file not found, using latest available`);
      return await this.getLatestTicketCSV();
    }
  }

  async uploadAnalysisResults(analysisData, filename) {
    try {
      const uploadPath = `${this.csvFolderPath}/Analysis_Results/${filename}`;
      
      await this.graphClient
        .api(`/sites/${this.siteId}/drives/${this.driveId}/root:${uploadPath}:/content`)
        .put(JSON.stringify(analysisData, null, 2));
        
      console.log(`📤 Analysis results uploaded: ${filename}`);
    } catch (error) {
      console.warn('⚠️ Failed to upload analysis results:', error);
      // Don't fail the main process if upload fails
    }
  }
}

module.exports = AzureSharePointService;