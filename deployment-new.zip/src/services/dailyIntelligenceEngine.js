const { differenceInBusinessDays, format } = require('date-fns');
const BusinessDayCalculator = require('../utils/businessDays');
const CSVParser = require('../utils/csvParser');
const EmailService = require('./emailService');

class DailyIntelligenceEngine {
  constructor() {
    this.businessDays = new BusinessDayCalculator();
    this.emailService = new EmailService();
    
    // Supervisor email for escalations
    this.supervisorEmail = process.env.SUPERVISOR_EMAIL || 'jhouchin@banyancenters.com';
    
    // AI evaluation criteria
    this.evaluationCriteria = {
      noResponseThreshold: 3, // 72 hours = 3 business days
      stuckTicketThreshold: 14, // 14+ days
      performanceReviewSample: 0.10 // 10%
    };
  }

  async runDailyIntelligence(ticketsCSVPath) {
    console.log('🧠 Starting Daily Helpdesk Intelligence Engine...');
    
    try {
      // Parse latest tickets
      const csvParser = new CSVParser();
      const tickets = await csvParser.parseTicketCSV(ticketsCSVPath);
      const openTickets = tickets.filter(ticket => this.isTicketOpen(ticket));
      const closedYesterday = this.getClosedYesterday(tickets);

      console.log(`📊 Processing ${openTickets.length} open tickets, ${closedYesterday.length} closed yesterday`);

      // Run all analyses
      const analyses = {
        dailyOverview: await this.generateDailyOverview(openTickets),
        noResponseAlerts: await this.identify72HourNoResponse(openTickets),
        stuckTicketEvaluations: await this.evaluateStuckTickets(openTickets),
        performanceReviews: await this.conductRandomPerformanceReviews(openTickets),
        closedTicketAnalysis: await this.analyzeClosedTickets(closedYesterday)
      };

      // Send notifications
      await this.sendDailyNotifications(analyses);

      console.log('✅ Daily Intelligence Engine completed successfully');
      return analyses;

    } catch (error) {
      console.error('❌ Daily Intelligence Engine failed:', error);
      
      // Send error notification
      await this.emailService.sendEmail({
        to: this.supervisorEmail,
        subject: '🚨 Daily Intelligence Engine Error',
        html: `
          <h2>Daily Intelligence Engine Failed</h2>
          <p>Error: ${error.message}</p>
          <p>Time: ${new Date().toLocaleString()}</p>
          <p>Please check the system and CSV file.</p>
        `
      });
      throw error;
    }
  }

  async generateDailyOverview(openTickets) {
    const overview = {
      totalOpen: openTickets.length,
      unassigned: openTickets.filter(t => !t.Tech_Assigned || t.Tech_Assigned.trim() === '').length,
      newToday: openTickets.filter(t => this.isCreatedToday(t)).length,
      highPriority: openTickets.filter(t => this.isHighPriority(t)).length,
      statusBreakdown: {},
      technicianWorkload: {},
      oldestTicket: null
    };

    // Status breakdown
    openTickets.forEach(ticket => {
      const status = ticket.Current_Status || 'Unknown';
      overview.statusBreakdown[status] = (overview.statusBreakdown[status] || 0) + 1;
    });

    // Technician workload
    openTickets.forEach(ticket => {
      if (ticket.Tech_Assigned_Clean) {
        const tech = ticket.Tech_Assigned_Clean;
        overview.technicianWorkload[tech] = (overview.technicianWorkload[tech] || 0) + 1;
      }
    });

    // Find oldest ticket
    if (openTickets.length > 0) {
      overview.oldestTicket = openTickets.reduce((oldest, ticket) => {
        const ticketAge = this.businessDays.getBusinessDaysSince(ticket.IssueDate);
        const oldestAge = this.businessDays.getBusinessDaysSince(oldest.IssueDate);
        return ticketAge > oldestAge ? ticket : oldest;
      });
    }

    return overview;
  }

  async identify72HourNoResponse(openTickets) {
    const alerts = [];
    
    openTickets.forEach(ticket => {
      const daysSinceCreated = this.businessDays.getBusinessDaysSince(ticket.IssueDate);
      const lastTechResponse = this.getLastTechResponse(ticket);
      
      // Check if it's been 72+ hours (3 business days) with no tech response
      if (daysSinceCreated >= this.evaluationCriteria.noResponseThreshold) {
        if (!lastTechResponse || this.businessDays.getBusinessDaysSince(lastTechResponse.date) >= 3) {
          alerts.push({
            ticket,
            daysSinceCreated,
            lastTechResponse,
            urgencyLevel: this.calculateUrgencyLevel(ticket, daysSinceCreated),
            recommendedAction: this.getNoResponseRecommendation(ticket, daysSinceCreated)
          });
        }
      }
    });

    return alerts.sort((a, b) => b.urgencyLevel - a.urgencyLevel);
  }

  async evaluateStuckTickets(openTickets) {
    const stuckTickets = openTickets.filter(ticket => 
      this.businessDays.getBusinessDaysSince(ticket.IssueDate) >= this.evaluationCriteria.stuckTicketThreshold
    );

    const evaluations = [];

    for (const ticket of stuckTickets) {
      const evaluation = await this.aiEvaluateStuckTicket(ticket);
      evaluations.push(evaluation);
    }

    return evaluations;
  }

  async aiEvaluateStuckTicket(ticket) {
    const age = this.businessDays.getBusinessDaysSince(ticket.IssueDate);
    const comments = ticket.comments || '';
    const status = ticket.Current_Status || '';
    const techResponses = this.countTechResponses(ticket);
    const userResponses = this.countUserResponses(ticket);
    const lastActivity = this.getLastActivityDate(ticket);
    
    // AI Decision Logic
    let recommendation = 'unknown';
    let reasoning = [];
    let confidence = 0;

    // Rule 1: User non-responsive
    if (this.hasUserNonResponsePattern(ticket)) {
      recommendation = 'close_no_user_response';
      reasoning.push('Multiple tech attempts with no user response');
      confidence += 0.8;
    }
    
    // Rule 2: Complex project indicators
    else if (this.isComplexProject(ticket)) {
      recommendation = 'move_to_project_management';
      reasoning.push('Complex scope requiring project management');
      confidence += 0.7;
    }
    
    // Rule 3: Simple stuck ticket
    else if (age >= 30 && techResponses < 3) {
      recommendation = 'push_to_closure';
      reasoning.push('Long duration with minimal tech engagement');
      confidence += 0.6;
    }
    
    // Rule 4: Waiting status too long
    else if (status.toLowerCase().includes('waiting') && age >= 21) {
      recommendation = 'close_no_user_response';
      reasoning.push('Waiting status exceeded reasonable timeframe');
      confidence += 0.7;
    }
    
    // Rule 5: High activity but no resolution
    else if (techResponses >= 5 && userResponses >= 3 && age >= 21) {
      recommendation = 'escalate_management';
      reasoning.push('High engagement but no resolution - needs management review');
      confidence += 0.8;
    }

    return {
      ticket,
      age,
      recommendation,
      reasoning,
      confidence: Math.min(confidence, 1.0),
      metrics: {
        techResponses,
        userResponses,
        lastActivity: lastActivity ? this.businessDays.getBusinessDaysSince(lastActivity) : null
      },
      suggestedActions: this.generateActionPlan(recommendation, ticket)
    };
  }

  async conductRandomPerformanceReviews(openTickets) {
    // Select random 10% of tickets
    const sampleSize = Math.max(1, Math.floor(openTickets.length * this.evaluationCriteria.performanceReviewSample));
    const selectedTickets = this.getRandomSample(openTickets, sampleSize);
    
    const reviews = [];
    
    for (const ticket of selectedTickets) {
      if (ticket.Tech_Assigned_Clean) {
        const review = await this.performanceReviewTicket(ticket);
        reviews.push(review);
      }
    }

    return reviews;
  }

  async performanceReviewTicket(ticket) {
    const age = this.businessDays.getBusinessDaysSince(ticket.IssueDate);
    const techResponses = this.getTechResponses(ticket);
    const userResponses = this.getUserResponses(ticket);
    const lastUpdate = this.getLastTechResponse(ticket);
    
    // Performance evaluation logic (similar to your manual reviews)
    const evaluation = {
      ticket,
      technician: ticket.Tech_Assigned_Clean,
      metrics: {
        responseCount: techResponses.length,
        userResponseCount: userResponses.length,
        age,
        lastUpdate: lastUpdate ? this.businessDays.getBusinessDaysSince(lastUpdate.date) : null
      },
      grade: 'C',
      strengths: [],
      weaknesses: [],
      recommendations: []
    };

    // Grading logic
    let score = 70; // Start with C grade

    // Response timeliness
    if (evaluation.metrics.responseCount === 0 && age >= 1) {
      score -= 30;
      evaluation.weaknesses.push('No technician response for ' + age + ' business days');
    }

    // Communication quality
    if (evaluation.metrics.responseCount > 0) {
      const avgResponseQuality = this.assessResponseQuality(techResponses);
      score += (avgResponseQuality - 0.5) * 20;
      
      if (avgResponseQuality > 0.7) {
        evaluation.strengths.push('Good communication quality');
      }
    }

    // Progress indicators
    if (evaluation.metrics.lastUpdate && evaluation.metrics.lastUpdate <= 2) {
      score += 10;
      evaluation.strengths.push('Recent activity');
    }

    // Convert score to grade
    evaluation.grade = this.scoreToGrade(score);
    evaluation.score = Math.max(0, Math.min(100, Math.round(score)));

    return evaluation;
  }

  async analyzeClosedTickets(closedTickets) {
    const analysis = {
      totalClosed: closedTickets.length,
      avgResolutionTime: 0,
      resolutionQuality: {},
      commonIssues: {},
      technicianPerformance: {}
    };

    if (closedTickets.length === 0) return analysis;

    // Calculate average resolution time
    const resolutionTimes = closedTickets
      .filter(t => t.IssueDate)
      .map(t => this.businessDays.getBusinessDaysSince(t.IssueDate));
    
    analysis.avgResolutionTime = resolutionTimes.length > 0 
      ? Math.round(resolutionTimes.reduce((sum, time) => sum + time, 0) / resolutionTimes.length)
      : 0;

    // Analyze each closed ticket
    for (const ticket of closedTickets) {
      const resolutionAnalysis = this.analyzeTicketResolution(ticket);
      
      // Update analysis data
      const tech = ticket.Tech_Assigned_Clean;
      if (tech) {
        if (!analysis.technicianPerformance[tech]) {
          analysis.technicianPerformance[tech] = {
            ticketsCompleted: 0,
            avgResolutionTime: 0,
            qualityScore: 0
          };
        }
        analysis.technicianPerformance[tech].ticketsCompleted++;
        analysis.technicianPerformance[tech].qualityScore += resolutionAnalysis.qualityScore;
      }
    }

    // Calculate averages
    Object.keys(analysis.technicianPerformance).forEach(tech => {
      const perf = analysis.technicianPerformance[tech];
      perf.qualityScore = Math.round(perf.qualityScore / perf.ticketsCompleted);
    });

    return analysis;
  }

  // Helper methods for analysis
  isTicketOpen(ticket) {
    const status = (ticket.Current_Status || '').toLowerCase();
    const closedStatuses = ['closed', 'resolved', 'completed', 'done'];
    return !closedStatuses.some(closedStatus => status.includes(closedStatus));
  }

  getClosedYesterday(tickets) {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    return tickets.filter(ticket => {
      const status = (ticket.Current_Status || '').toLowerCase();
      const closedStatuses = ['closed', 'resolved', 'completed', 'done'];
      const isClosed = closedStatuses.some(closedStatus => status.includes(closedStatus));
      
      // This is simplified - in real implementation you'd check actual close date
      return isClosed;
    });
  }

  getRandomSample(array, sampleSize) {
    const shuffled = [...array].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, sampleSize);
  }

  scoreToGrade(score) {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
  }

  // Additional helper methods would go here...
  getTechResponses(ticket) {
    // Parse comments to extract tech responses
    // This would need detailed parsing of the comments field
    return [];
  }

  getUserResponses(ticket) {
    // Parse comments to extract user responses
    return [];
  }

  // More helper methods...
}

module.exports = DailyIntelligenceEngine;